package util;
/**
 * Open firewll on the linux VM (centos) to allow incoming connection on port 9876.
 * sudo firewall-cmd --zone=public --add-port=9876/tcp 		[--permanent]
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import org.w3c.dom.Document;

import com.yantra.interop.japi.YIFApi;

public class SterlingTestServer {

	
	ServerSocket serverSocket = null;
	int serverPort = 9876;
	boolean isStopped = false;
	boolean isDebug = true;
	String sterlingTimeout = "300000"; // 5 minutes
	//private static HashMap<String, YIFApi> apiMap = new HashMap<String, YIFApi>();
	private static HashMap<String, String> tokenMap = new HashMap<String, String>();
	private static YIFApi api = null;
	
	public static void main(String[] s) throws IOException {
		
		SterlingTestServer sterlingTestServer = new SterlingTestServer();
		if (s != null && s.length > 0) {
			for (int i = 0 ; i < s.length; i++) {
				if (s[i].equals("-port")) {
					try {
						sterlingTestServer.serverPort = Integer.parseInt(s[i].replaceAll("-port=", ""));
					} catch (java.lang.Throwable e) {
						throw new IOException("Invalid Port# " + s[0]);
					}
				} else if (s[i].equals("-nodebug")) {
					sterlingTestServer.isDebug = false;
				} else 	if (s[i].equals("-timeout")) {
					sterlingTestServer.sterlingTimeout = s[i];
				}
			}
			sterlingTestServer.openServerSocket();
			sterlingTestServer.listen();
		} else {
			sterlingTestServer.printUsage();
		}
	}
	
    private void openServerSocket() {
        try {
            serverSocket = new ServerSocket(this.serverPort, 0, InetAddress.getByAddress(new byte[] {0x00,0x00,0x00,0x00}));
		   log("Socket Opened.");
        } catch (IOException e) {
            throw new RuntimeException("Cannot open port ", e);
        }
    }	
	
	private void listen() {
		   log("listening.");
	    while(! isStopped()){
	        Socket clientSocket = null;
	        try {
		   log("Waiting.");
	            clientSocket = serverSocket.accept();
	        } catch (IOException e) {
	            if(isStopped()) {
	                log("Server Stopped.") ;
	                return;
	            }
	            throw new RuntimeException(
	                "Error accepting client connection", e);
	        }
	        
	            new Thread(
	            new WorkerThread(
	            clientSocket)
	            ).start();
	        
	    }			
	}
	
    private synchronized boolean isStopped() {
        return this.isStopped;
    }
    
    public synchronized void stop(){
        this.isStopped = true;
        try {
            this.serverSocket.close();
        } catch (IOException e) {
            throw new RuntimeException("Error closing server", e);
        }
    }
    
    private void log(String s) {
    	if (isDebug) {
    		System.out.println(new Date() + ": " + s);
    	}
    }
    
    private void printUsage() {
    	System.err.println("Usage: java SterlingTestServer [-port=<port#>] [-nodebug] [-timeout=milliseconds]");
    	System.err.println("Defaults:\n port: " + this.serverPort);
    	System.err.println("logging: verbose logging.");
    	System.err.println("timeout: " + this.sterlingTimeout + " millis.");
    }
	
	class WorkerThread implements Runnable{

	    protected Socket clientSocket = null;
	    
	    
	    public WorkerThread(Socket clientSocket) {
	        this.clientSocket = clientSocket;
	    }

	    public void run() {
	    	log("*****New Worker");
	    	String sessionId = null;
	        try {
	            InputStreamReader input  = new InputStreamReader(clientSocket.getInputStream());
	            BufferedReader reader = new BufferedReader(input);
	            String line = reader.readLine(); 
	            StringBuffer sbf = new StringBuffer("");
	            while (line != null && !line.isEmpty()) {
	                line = reader.readLine();
	                sbf.append(line + "\n");
	                if (line.contains("Cookie") &&
	                	line.contains(" sessionid")) {
	                	sessionId = getCookie(line);
	                }
	            }
	            //log(sbf.toString());
	            StringBuffer payload = new StringBuffer("");
	            while (reader.ready()) {
	                payload.append((char) reader.read());
	                payload.append(line);
	            }
	            if (payload.toString().length() == 0 ) {
	            	log(".");
	            	return;
	            }	            
	            if (!isDebug) {
	            	payload.append("&-nodebug");
	            }
	            //log(payload.toString());
	            
	            String[] params = payload.toString().split("&");
	            for (int p = 0 ; p < params.length; p++) {
	            	params[p] = URLDecoder.decode(params[p], "UTF-8");
	            	//log(params[p]);
	            }
	            
	            SterlingTester tester = new SterlingTester();
	            tester.STERLING_TIMEOUT = sterlingTimeout;
	            Document doc = null;
	            
	            String token = null;
	            YIFApi api = null;
	            if (sessionId != null) {
		            token = tokenMap.get(sessionId);
		            //api = apiMap.get(sessionId);
	            }
	            
		        String outXml = "<NoReply/>";
		        log("Sending Request to Sterling OMS: " + new Date());
	            try {
	            	tester.setAPI(api);
	            	tester.setToken(token);
	            	doc = tester.runTest(params);
	            	if (doc != null) {
	            		outXml = tester.getXmlString(doc);
	            		token = tester.getToken();
	            		api = tester.getAPI();
	            		if (!tester.isUserAuthorized(doc)) {
	            			invalidateSession(sessionId);
	            		} else {
	                        createSession(sessionId, api, token);
	            		}
	            	}
	            } catch(Exception e) {
	            	e.printStackTrace();
	            }
	            log("Got Response from Sterling OMS: " + new Date());
	            if (sessionId == null) {
	            	sessionId = getUUID();
	            }
	            
	            OutputStream output = clientSocket.getOutputStream();

	            PrintWriter writer = new PrintWriter(output);
	            writeHeaders(writer, sessionId, api, token);
	            writer.println(outXml);
	            writer.flush();
	            writer.close();
	            output.close();
	            input.close();

	        } catch (IOException e) {
	            //report exception somewhere.
	            e.printStackTrace();
	        }
	    }
	    
	    private String getUUID() {
	    	UUID uuid = UUID.randomUUID();
	    	return uuid.toString();
	    }
	    private String getCookie(String line) {
	    	log("getCookie :" + line);
	    	String sid = null;
	    	String[] s = line.split("=");
	    	if (s != null && s.length > 0) {
	    		sid = s[s.length - 1];
	    		log(sid);
	    	}
	    	return sid;
	    }
	    private void writeHeaders(PrintWriter writer, String sessionId, YIFApi api, String token) {
            writer.println("HTTP/1.0 200 OK");
            writer.println("Server: SterlingTestServer/1.0");
            writer.println("Content-Type: application/xml");
            writer.println("Set-Cookie: sessionid=" + sessionId);
            writer.println(); // must have this blank line after all headers 
	    }
	    
	    private void createSession(String sessionId, YIFApi api, String token) {
            tokenMap.put(sessionId, token);
           // apiMap.put(sessionId, api);
	    }
	    
	    private void invalidateSession(String sessionId) {
    			//apiMap.remove(sessionId);
    			tokenMap.remove(sessionId);
	    }
	}	
	
	
}
