package util;
/**
 * This class runs Customer API class or OOB APi or Service from command line.
 * 
 * Command Line Parameters:
 * 			-u=Sterling login id
 * 			-p=password
 * 			-c=component name  	 (Can be custom api class name or oob api name or a service name
 * 								 eg: -c=com.xxx.smcfs.api.shipment.ProcessASNMessage  or  -c=scheduleOrder or -c=CustomProcessOrderService) 
 * 			-m=method to run     (Name of the method in custom api class.
 * 								 eg: -m=invoke 
 * 								 Required only when a custom api component is being run.
 *			-k=custom|oob|service (kind of component. can be a custom api or out-of-box sterling api or service)
 *								 eg: -k=custom  -k=oob  -k=service  default is custom.) 
 * 			-i=input xml file	 (eg: -i=order.xml)
 * 			-t=template xml file (eg: -t=order_template.xml) 
 *			-nodebug			 (by default, when a custom API is run, it will be run in verbose mode unless -nodebug parameter is passed
 *								 eg: -nodebug )
 *			-console             (display output xml on the screen. if -console option not used, the output is written to file in $HOME/tester/output folder)
 *
 * @author jaydeep.parikh
 *
 *
Windows Batch FIle to run this class:

cls
@REM define 'yfs.api.security.enabled=Y' in custom_overrides.properties
@REM define 'yfs.api.security.token.enabled=Y' in custom_overrides.properties

@ECHO OFF
setlocal


call C:\Users\IBM_ADMIN\opt\IBM\bin\tmp.cmd


set AGENT_JAVA_OPTS= -Dvendor=shell -DvendorFile=C:/Users/IBM_ADMIN/opt/IBM/properties/servers.properties -DCACHE_PS=true -DDISABLE_DS_EXTENSIONS=Y

%AGENT_JAVA% -classpath C:/Users/IBM_ADMIN/opt/IBM/jar/bootstrapper.jar %AGENT_JAVA_OPTS% com.sterlingcommerce.woodstock.noapp.NoAppLoader  -f C:/Users/IBM_ADMIN/opt/IBM/properties/APPDynamicclasspath.cfg -class SterlingTester %*


goto END

:END
endlocal
 *
 *
 */


import java.lang.reflect.Method;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import java.io.StringWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileDescriptor;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;

import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfs.japi.YFSEnvironment;

public class SterlingTester {

	public static String STERLING_TIMEOUT = "300000"; // 5 minutes
	private static boolean isDebug = true;
	private static boolean isDisplayOutput = false;
	private YIFApi api = null;
	private String token = null;
	
	private static String mode = ""; 
	private static String outputFolder = System.getProperty("user.home") +  "/tester/output";
	private static String logFolder = System.getProperty("user.home") +  "/tester/logs";

	private static Object lock = new Object();
	
	/**
	 * Read xml file to be used as input to Custom API.
	 * 
	 *  (Method used only for testing purposes)
	 * reads a file (xml file) for the purpose of unit testing from command prompt
	 */
	private String readFile(String fileName) throws Exception {
		   java.io.FileInputStream ifs = new java.io.FileInputStream(new java.io.File(fileName));
		   int bytesAvailable = ifs.available();
		   byte[] bt = new byte[bytesAvailable];
		   ifs.read(bt);
		   String data = new String(bt);
		   ifs.close();
		   return data;

	}

	/**
	 *  Create XML document from xml string.
	 *  
	 *  (Method used only for testing purposes)
	 * converts xml string to DOM
	 */
	public Document getDocument(String data) throws Exception {
			if (data != null && data.trim().length() != 0) {
			    org.xml.sax.InputSource inSource = new org.xml.sax.InputSource(new java.io.StringReader(data));
	
				javax.xml.parsers.DocumentBuilderFactory fac = javax.xml.parsers.DocumentBuilderFactory.newInstance();
	
				fac.setNamespaceAware(false);
				javax.xml.parsers.DocumentBuilder dbdr = fac.newDocumentBuilder();
	
				return dbdr.parse(inSource);
			}
			return null;
	}
	
	public Document createDocument(String docElementTag) throws ParserConfigurationException {
		DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();

		DocumentBuilder dbdr = fac.newDocumentBuilder();

		Document doc = dbdr.newDocument();
		Element ele = doc.createElement(docElementTag);
		doc.appendChild(ele);
		return doc;
	}	
	
	public String getXmlString(Document doc) throws Exception {
		//log("inside getXmlString");
		OutputFormat outFmt = new OutputFormat("xml", "iso-8859-1", true);
		outFmt.setOmitXMLDeclaration(true);
		StringWriter strWriter = new StringWriter();
		XMLSerializer xmlSerializer = new XMLSerializer(strWriter, outFmt);
		xmlSerializer.serialize(doc);
		//log("exiting getXmlString");
		return strWriter.toString();
	}		

	/**
	 *  Generate YFSEnvironment xml document.
	 *  
	 *  (Method used only for testing purposes)
	 * Creates an instance of YFSEnvironment, for the purpose of unit testing from command prompt
	 */
	private YFSEnvironment getEnvironment(Object c, String userID, String password) throws Exception {

		String progid = "";
		if (c instanceof Class) {
			progid = ((Class) c).getClass().getName();
		} else  {
			progid = (String) c;
		}
		String envXmlString = "<YFSEnvironment progId='" + progid + "' userId='" + userID + "' password='" + password + "'/>" ;

		Document envXml = getDocument(envXmlString);

		api= getSterlingAPIInstance();
		YFSEnvironment env = api.createEnvironment(envXml);

		return env;
	}

	/**
	 * Generate Session Token using login api
	 *  
	 * @param env
	 * @param userID
	 * @param password
	 * @return
	 * @throws Exception
	 */
	private String getToken(YFSEnvironment env, String userID, String password) throws Exception {
		String tkn = "";
		if (token != null && (password == null || password.trim().length() == 0)) {
			tkn = token;
		} else {
			log("Generating new token...");
			api = getSterlingAPIInstance();
			Document input = getDocument("<Login LoginID='" + userID + "' Password='" +  password + "' Timeout='" + STERLING_TIMEOUT + "'/>");
			Document result = api.invoke(env, "login", input);
			if (result != null) {
				Element login = (Element) result.getElementsByTagName("Login").item(0);
				if (login != null) {
					tkn = login.getAttribute("UserToken");
				}
			}
		}
		return tkn;
	}
	
	private YIFApi getSterlingAPIInstance() throws YIFClientCreationException {
		if (api == null) {
			log("Generating new YIFApi...");
			synchronized(lock) {
				api = YIFClientFactory.getInstance().getApi("LOCAL");
			}
		} 
		return api;
	}		


	/**
	 * To be used for the purpose of unit testing from command prompt.
	 * 
	 * Accepts parameters:
	 * 			-u=SterlingLoginId
	 * 			-p=Password
	 *			-k=custom|oob|service (kind of component. can be a custom api or out-of-box sterling api or service
	 *								 eg: -k=custom  -k=oob   -k=service  default is custom.) 
	 * 			-c=component name	(eg: com.custom.smcfs.api.shipment.CustomProcessASNMessage  or createOrder  or CustomProcessOrderService) 
	 * 			-m=method to run    (eg: invoke) 
	 * 			-i=input xml file	(eg: order.xml)
	 * 			-t=template xml file	(eg: order_template.xml)
	 *			-nodebug			 (by default, when a custom API is run, it will be run in verbose mode unless -nodebug parameter is passed)
	 *          -console             (display output xml on the screen. if -console option not used, the output is written to file in $HOME/tester/output folder)
	 * 
	 * 
	 */
	public static void main(String[] s) throws Exception {
		
		SterlingTester tester = new SterlingTester();
		tester.mode = "CLI";
		Document reply = tester.runTest(s);
		
		System.exit(0);	
	}
	
	
	public Document runTest(String[] s) throws Exception {

		Document reply = null;
		PrintStream logStream = null;
		
		
		try {
				Properties props = new Properties();
				String userID = "";
				String password = "";
				String codeToTest = null;
				String methodToRun = null;
				String inputXMLFile = null;
				String templateXMLFile = null;
				boolean isOOBApi = false;
				boolean isService = false;
				boolean isCustomApi = true; // if -k param not defined, default the component type as 'custom'
				String outputXMLFile = null;
				String xmlInput = null; // can have xml string when -ix param is used
				String xmlTemplate = null; // can have xml string when -tx param is used
				
				
				for (int i = 0; i < s.length; i++) {
					//log(s[i]);
					if (s[i].startsWith("-c=")) {
						// component name (ap or service name)
						codeToTest = s[i].replace("-c=", "");
					} else if (s[i].startsWith("-m=")) {
						// method name
						methodToRun = s[i].replace("-m=", "");
					} else if (s[i].startsWith("-i=")) {
						// input xml file name
						inputXMLFile = s[i].replace("-i=", "");
					} else if (s[i].startsWith("-u=")) {
						// user id - sterling login id
						userID = s[i].replace("-u=", "");
					} else if (s[i].startsWith("-p=")) {
						// password
						password = s[i].replace("-p=", "");
					} else if (s[i].startsWith("-a=")) {
						// optional arguments to be passed on to the custom api
						if (s[i].indexOf("=")+1 < s[i].lastIndexOf("=")) {
							String k = s[i].substring(s[i].indexOf("=")+1,s[i].lastIndexOf("="));
							String v = s[i].substring(s[i].lastIndexOf("=")+1);
							log(k + " : " + v);
							props.setProperty(k,v);
						}
					} else if (s[i].startsWith("-k=")) {
						// kind of component - custom, oob, service
						if (s[i].equals("-k=oob")) {
							isOOBApi = true;
							isService = false;
							isCustomApi = false;
						} else if (s[i].equals("-k=service")) {
							isService = true;
							isOOBApi = false;
							isCustomApi = false;
						} else {
							isCustomApi = true;
							isOOBApi = false;
							isService = false;
						}
					} else if (s[i].startsWith("-nodebug")) {
						// do not do verbose logging
						isDebug = false;
					} else if (s[i].startsWith("-t=")) {
						// template xml file name
						templateXMLFile = s[i].replace("-t=", "");
					} else if (s[i].startsWith("-console")) {
						// display ouput xml on screen instead of saving in output file
						isDisplayOutput = true;
					} else if (s[i].startsWith("-ix=")) { 
						// used to pass input xml string as input parameter (an alternative to -i param)
						xmlInput = s[i].substring(4);
					} else if (s[i].startsWith("-tx=")) { 
						// used to pass template xml string as input parameter (an alternative to -t param)
						xmlTemplate = s[i].substring(4);
					}
				}
				
				if (codeToTest == null || (methodToRun == null && isCustomApi) || (inputXMLFile == null && xmlInput == null)) {
					
					if (mode.equals("CLI")) {
						System.exit(1);
						parametersMissing();
					}
				}
		
				
				logStream = redirectToLogFile(inputXMLFile);			
				log("Started Test.");
		
		
				if (isOOBApi) {
					log("Running OOB API: " + codeToTest);
					
					if (api == null) {
						api = getSterlingAPIInstance();
					}
		
					YFSEnvironment env = getEnvironment(codeToTest, userID, password);
					token = getToken(env, userID, password);
					
					log("Got user token: " + token);
					
					env.setTokenID(token);
					
					Document templateDoc = null;
					if (xmlTemplate == null || xmlTemplate.trim().length() == 0) {
						if (templateXMLFile != null) {
							templateDoc = getDocument(readFile(templateXMLFile));
						}
					} else {
						templateDoc = getDocument(xmlTemplate);
					}
					if (templateDoc != null) {
						env.setApiTemplate(codeToTest, templateDoc);
					}
		
					Document indoc = null;
					if (xmlInput == null) {
						indoc = getDocument(readFile(inputXMLFile));
					} else {
						indoc = getDocument(xmlInput);
					}	
					
					reply = (Document) api.invoke(env, codeToTest, indoc);
		
					env.clearApiTemplate(codeToTest);
					
					log("Done Running OOB API: " + codeToTest);
					if (reply  == null) {
						log("API returned null.");
					} else {
						if (!isDisplayOutput) {
							outputXMLFile = saveOutput(inputXMLFile, getXmlString(reply));
						}
					}
				
				} else if (isService) {
					
					if (api == null) {
						api = getSterlingAPIInstance();
					}
		
					YFSEnvironment env = getEnvironment(codeToTest, userID, password);
					token = getToken(env, userID, password);
					
					log("Got user token: " + token);
					
					env.setTokenID(token);
					
					Document indoc = null;
					if (xmlInput == null) {
						indoc = getDocument(readFile(inputXMLFile));
					} else {
						indoc = getDocument(xmlInput);
					}			
		
					reply = (Document) api.executeFlow(env, codeToTest, indoc);
					log("Done Running Service: " + codeToTest);
					if (reply  == null || !(reply instanceof Document)) {
						log("Service returned null.");
					} else {
						if (!isDisplayOutput) {
							outputXMLFile = saveOutput(inputXMLFile, getXmlString(reply));
						}
					}
					
				} else {
					
					Class c =  Class.forName(codeToTest, true, getClass().getClassLoader());
					log("Class Loaded: " + c.getName());
				
					/*
					if (isDebug) {
						// print all logging statements while testing
						Field[] f = c.getDeclaredFields();
						for (int i = 0; i < f.length; i++) {
							log("Field in Class Loaded: " + f[i].getName() + " " + f[i].getGenericType().toString());
							if (f[i].getGenericType().toString().equals("class com.yantra.yfc.log.YFCLogCategory")) {
								log("Turning logging on.");
								f[i].setAccessible(true);
								com.yantra.yfc.log.YFCLogCategory log = (com.yantra.yfc.log.YFCLogCategory)  f[i].get(com.yantra.yfc.log.YFCLogCategory.instance("com.yantra"));
								log.setLogAll(true);
							}
						}
					}
					*/
					
					Object classObject = c.newInstance();
					
					if (props.size() > 0) {
					   Class[] propsParam = new Class[1];
					   propsParam[0] = java.util.Properties.class;
					   Method setProperties = c.getMethod("setProperties", propsParam);
						   setProperties.invoke(classObject, props);
					}
			
		
		
					Class[] params = new Class[2];
					params[0] = YFSEnvironment.class;
					params[1] = Document.class;
		
					Method m = c.getMethod(methodToRun, params);
					log("Method loaded: " + m.getName());
					
					YFSEnvironment env = getEnvironment(c, userID, password);
					token = getToken(env, userID, password);
					
					log("Got user token: " + token);
					
					env.setTokenID(token);
		
		
					log("Running method: " + m);
					Document indoc = null;
					if (xmlInput == null) {
						indoc = getDocument(readFile(inputXMLFile));
					} else {
						indoc = getDocument(xmlInput);
					}
					Object obj = m.invoke(classObject, env, indoc);
					log("Done Running " + m + " method in class " + c.getName());
					if (obj != null && obj instanceof Document) {
						reply = (Document) obj;
						if (!isDisplayOutput) {
							outputXMLFile = saveOutput(inputXMLFile, getXmlString(reply));
						}
					}
				}
		
				log("Exiting Test.");
				if (mode.equals("CLI")) {
					resetRedirection();
					if (!isDisplayOutput && outputXMLFile != null) {
						log("*****OUTPUT FILE NAME: " + outputXMLFile );
					} else {
						if (reply  != null && (reply instanceof Document)) {
							System.out.println("*****REPLY:\n" + getXmlString(reply));
						} else {
							System.out.println("*****NO REPLY XML.");
						}
					}
				}

		} catch (java.lang.NoClassDefFoundError e) {
			//System.out.println("Catching NoClassDefFoundError");
			reply = handleError(e);
			//System.out.println(this.getXmlString(reply));
		} catch (java.lang.ClassNotFoundException e) {
			//System.out.println("Catching ClassNotFoundException");
			reply = handleError(e);
			//System.out.println(this.getXmlString(reply));
		} catch (Exception e) {
			//System.out.println("Catching Exception");
			reply = handleError(e);
			//System.out.println(this.getXmlString(reply));
		} finally {
			try {
				if (logStream != null) {
					logStream.flush();
					logStream.close();
				}
			} catch(Exception ee) {}
		}

		return reply;
	}

	private static void log(String s) {
		if (isDebug) {
			System.out.println(new java.util.Date()  + " Tester: " + s);
		} 
	}
	
	private Document handleError(java.lang.Throwable e) {
		Document errDoc = null;
		boolean isStackTraceErrorsDoc = false;
		StringWriter sw = null;
		PrintWriter pw = null;		
		try {
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			pw.flush();
			sw.flush();			
			try {
				errDoc = this.getDocument(sw.toString());
				if (errDoc.getDocumentElement().getNodeName().equals("Errors")) {
					isStackTraceErrorsDoc = true;
				}
			} catch (Exception ee) {}
			if (!isStackTraceErrorsDoc) {
				errDoc = createDocument("Errors");
				Element docEle = errDoc.getDocumentElement();
				docEle.appendChild(errDoc.createTextNode(sw.toString()));
			}
		} catch (Exception ee) {}
		finally {
			try {
				pw.close();
				sw.close();
			} catch (Exception xx) {}
		}
		e.printStackTrace();	
		return errDoc;
	}
	
	private String saveOutput(String inputXMLFile, String replyXML) throws Exception {
		String outputXMLFile = inputXMLFile;
		if (outputXMLFile != null && outputXMLFile.trim().length() != 0) {
			if (mode.equals("CLI")) {
				if (!isDisplayOutput) {
					if (!Files.exists(Paths.get(outputFolder))) {
						File dir = new File(outputFolder);
						dir.mkdirs();
					}
					if (inputXMLFile.contains(".")) {
						int startPos = inputXMLFile.lastIndexOf(File.separator) > -1 ? 
								inputXMLFile.lastIndexOf(File.separator) + 1 : 0;						
						outputXMLFile = inputXMLFile.substring(startPos, inputXMLFile.lastIndexOf("."));
					}
					outputXMLFile = outputFolder + File.separator + outputXMLFile.concat("_out.xml");
					PrintWriter wrt = new PrintWriter(outputXMLFile);
					wrt.write(replyXML);
					wrt.flush();
					wrt.close();
				} 
			}
		}
		return outputXMLFile;
	}
	
	private PrintStream redirectToLogFile(String inputXMLFile) throws FileNotFoundException {
		String logFile = inputXMLFile;
		if (logFile != null && logFile.trim().length() != 0) {
			if (!Files.exists(Paths.get(logFolder))) {
				File dir = new File(logFolder);
				dir.mkdirs();
			}
			if (inputXMLFile.contains(".")) {
				int startPos = inputXMLFile.lastIndexOf(File.separator) > -1 ? 
						inputXMLFile.lastIndexOf(File.separator) + 1 : 0;
				logFile = inputXMLFile.substring(startPos, inputXMLFile.lastIndexOf("."));
			}
			logFile = logFolder + File.separator + logFile.concat(".log");
			
			PrintStream log = new PrintStream(logFile);
			System.out.println("*****LOG FILE NAME: " + logFile );
			System.setErr(log);
			System.setOut(log);
			return log;
		}
		return null;
	}
	
	private void resetRedirection() throws Exception {
		PrintStream log = new PrintStream(new FileOutputStream(FileDescriptor.out));
		System.setOut(log);
		System.setErr(log);
	}

	public YIFApi getAPI() throws YIFClientCreationException {
		return api;
	}

	public String getToken() {
		return token;
	}

	public void setAPI(YIFApi theApi) {
		api = theApi;
	}

	public void setToken(String theToken) {
		token = theToken;
	}
	
    public boolean isUserAuthorized(Document doc) {

    	try {
    		//System.out.println("isUserAuthorized input: " + this.getXmlString(doc));
    	} catch (Exception e)  {}
    	
    	
    	boolean isUserAuthorized = true;
    	Element rootEle = doc.getDocumentElement();
    	
    	
    	NodeList errorsList = rootEle.getElementsByTagName("Error");
    	
    	    	
    	for (int e = 0; errorsList != null && e < errorsList.getLength(); e++ ) {
    		Element errors = (Element) errorsList.item(e);
    		String errorCode = errors.getAttribute("ErrorCode");
    		log(errorCode);
    		if (errorCode.equals("YCP0427")) {
    			isUserAuthorized = false;
    			log("User is not authorized.");
    		}
    	}
    	//System.out.println("Exiting isUserAuthorized with: " + isUserAuthorized);
    	return isUserAuthorized;
    }
    
	private void parametersMissing() {
		System.err.println("\nMissing one or more paramaters: -u=<loginid> -p=<password> -c=<component> -m=<method> -i=<inputXmlFile> [-t=templateXmlFile] [-k=custom|api|service] [-nodebug] [-a=<ArgumentName>=<ArgumentValue> ...]\n");
		System.err.println("	 * Accepts parameters:\r\n" + 
				"	 * 	-u=SterlingLoginId   (A valid Sterling login id)\r\n" + 
				"	 * 	-p=Password          (Sterling user's password)\r\n" + 
				"	 * 	-c=component name    (name of API or Service. eg: -c=com.custom.smcfs.api.shipment.CustomProcessASNMessage  or -c=createOrder  or -c=CustomProcessOrderService) \r\n" + 
				"	 * 	-m=method to run     (method to invoke in custom api. only needed when running a custom api. eg: -m=invoke) \r\n" + 
				"	 * 	-i=input xml file    (input xml file name. eg: -i=order.xml)\r\n" + 
				"	 * 	-t=template xml file (optional parameter for template xml file name. eg: -t=order_template.xml)\r\n" + 
				"    *  -k=custom|oob|service (kind of component. can be a custom api or out-of-box sterling api or service). eg: -k=custom  -k=oob  -k=service default is custom.)\r\n" +  
				"	 *	-nodebug             (optional parameter, without this flag the API/Service runs in verbose mode. eg: -nodebug)\r\n" +
				"	 *	-console             (display output xml on the screen. if -console option not specified, the output is written to a file in " + outputFolder + " folder)\r\n");
		System.err.println("Examples:\n");
		System.err.println("Parameters for running custom API:\n -u=jaydeep.parikh -p=thepassword -c=com.xyz.order.api.CustomProcessOrder -m=invoke -i=process_order.xml");
		System.err.println("Parameters for running OOB API:\n -c=getOrderDetails -k=oob -i=/tmp/go.xml -t=/tmp/t.xml -console -nolog");
		System.err.println("Parameters for running Service:\n -u=jaydeep.parikh -p=thepassword -c=ConfirmShipmentService -k=service -i=order.xml");
		System.err.println("Parameters for running custom API with attributes:\n -u=jaydeep.parikh -p=thepassword -c=com.xyz.order.api.CustomProcessShipment -m=invoke -i=process_order.xml -a=LINE_TYPE=GC -a=ORDER_TYPE=WEB");
		System.err.println("\nOutput xml is saved in the " + outputFolder + " folder.");
		System.err.println("Output File Name: <InputFileName>_out.xml\n");
	}
}
