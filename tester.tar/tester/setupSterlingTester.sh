#!/bin/sh

setup_cfg() {
   echo 'VENDOR_JAR=.' > ./SterlingTester.cfg
   cat $1 >> ./SterlingTester.cfg
}
setup_server_script() {
   echo '#!/bin/sh' >  SterlingTestServer.sh
   echo "export RT='${rtfolder}'" >> SterlingTestServer.sh
   cat  SterlingTestServer.sh.template >> SterlingTestServer.sh 
}
setup_tester_script() {
   echo '#!/bin/sh' >  SterlingTester.sh
   echo "export RT='${rtfolder}'" >> SterlingTester.sh
   cat  SterlingTester.sh.template >> SterlingTester.sh 
}
error() {
   echo "Error: Could not find $1"
   echo "Please provide the correct Sterling runtime folder path."
}

rtfolder=''

mkdir -p ~/tester/logs
mkdir -p ~/tester/output

cd ~/tester

while [ -z "${rtfolder}" ]
do
   echo -n "Sterling runtime folder: "
   read rtfolder
done

propfile="${rtfolder}/properties/AGENTDynamicclasspath.cfg"
if [ -f "${propfile}" ]
then
   setup_cfg "${propfile}"
   setup_server_script
   setup_tester_script
   chmod +x Sterling*sh
   echo "Setup complete."
else
  error ${propfile}
fi
