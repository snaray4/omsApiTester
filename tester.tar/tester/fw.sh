if [ $# == 1 ]
then
sudo firewall-cmd --zone=public --add-port=$1/tcp
sudo firewall-cmd --list-all
fi
